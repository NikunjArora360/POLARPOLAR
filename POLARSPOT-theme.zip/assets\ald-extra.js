/* Saved list: hearts on cards and product pages, a header heart with a count, and a drawer with a share button. Stored in this browser only. */
(function () {
  var KEY = 'ald-saved', fetched = 0, q = 0, panel, body, foot;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var HEART = "<svg class='ald-ic' viewBox='0 0 24 24' aria-hidden='true'><path d='M12 20.5C5 16 2.5 12.5 2.5 9A4.8 4.8 0 0 1 12 8A4.8 4.8 0 0 1 21.5 9C21.5 12.5 19 16 12 20.5Z'/></svg>";
  function load() { try { var v = JSON.parse(localStorage.getItem(KEY) || '[]'); return Array.isArray(v) ? v : []; } catch (e) { return []; } }
  function save() { try { localStorage.setItem(KEY, JSON.stringify(list)); } catch (e) {} }
  var list = load();
  function idx(h) { for (var i = 0; i < list.length; i++) if (list[i].h === h) return i; return -1; }
  function handleOf(href) { var m = /\/products\/([^\/?#]+)/.exec(href || ''); return m ? decodeURIComponent(m[1]) : ''; }
  function toggle(item) { var i = idx(item.h); if (i > -1) list.splice(i, 1); else list.unshift(item); save(); sync(); }
  function txt(n) { return n ? n.textContent.trim() : ''; }
  function cardHandle(c) { var a = $('a[href]', c); return c.getAttribute('data-h') || (a ? handleOf(a.getAttribute('href')) : ''); }
  function fromCard(c) {
    var im = $('.ald-card__m img', c), mrp = $('.ald-pr s', c);
    return { h: cardHandle(c), t: txt($('.ald-card__t', c)), i: im ? im.currentSrc || im.getAttribute('src') : '', p: txt($('.ald-pr b', c)), m: mrp ? txt(mrp).replace(/^MRP\s*/, '') : '' };
  }
  function decorate() {
    $$('.ald-card:not([data-sv-done])').forEach(function (c) {
      c.setAttribute('data-sv-done', '1');
      var m = $('.ald-card__mw', c), h = cardHandle(c);
      if (!m || !h) return;
      var b = document.createElement('button');
      b.type = 'button'; b.className = 'ald-heart'; b.setAttribute('data-sv', h); b.innerHTML = HEART;
      b.setAttribute('aria-label', 'Save ' + txt($('.ald-card__t', c)));
      b.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); toggle(fromCard(c)); });
      m.appendChild(b);
    });
  }
  function pdp() {
    var l = $('.ald-pdp__info');
    if (!l || $('.ald-savebtn')) return;
    var h = handleOf(location.pathname), p = $('[data-ald-buy]', l);
    if (!h || !p) return;
    var b = document.createElement('button');
    b.type = 'button'; b.className = 'ald-savebtn'; b.setAttribute('data-sv', h); b.innerHTML = HEART + '<span>Save</span>';
    b.addEventListener('click', function () {
      var im = $('.ald-pdp__scroll img');
      var mrp = $('.ald-pdp__p [data-ald-mrp]');
      toggle({ h: h, t: txt($('.ald-pdp__t')), i: im ? im.currentSrc || im.getAttribute('src') : '', p: txt($('.ald-pdp__p .ald-pr b')), m: mrp && !mrp.hidden ? txt(mrp.lastElementChild) : '' });
    });
    p.parentNode.insertBefore(b, p.nextSibling);
  }
  function header() {
    var r = $('.ald-hdr__r');
    if (!r || $('[data-ald-open=saved]')) return;
    var b = document.createElement('button');
    b.type = 'button'; b.className = 'ald-hdr__sv'; b.setAttribute('data-ald-open', 'saved'); b.setAttribute('aria-label', 'Saved items');
    b.innerHTML = HEART + '<span data-ald-saved-count></span>';
    r.insertBefore(b, $('.ald-cnt', r) || null);
  }
  function build() {
    panel = document.createElement('aside');
    panel.className = 'ald-sv ps-drawer ps-drawer--r'; panel.setAttribute('role', 'dialog'); panel.setAttribute('aria-modal', 'true'); panel.setAttribute('aria-label', 'Saved items');
    panel.innerHTML = "<div class='ps-drawer__hd'><span>Saved</span><button type='button' data-ald-close aria-label='Close saved items'><svg class='ald-ic' viewBox='0 0 20 20' aria-hidden='true'><path d='M4 4l12 12M16 4L4 16'/></svg></button></div><div class='ald-sv__body'></div><div class='ald-sv__ft'><button type='button' class='ald-btn ald-btn--light' data-sv-share>Share my list</button></div>";
    document.body.appendChild(panel);
    body = $('.ald-sv__body', panel); foot = $('.ald-sv__ft', panel);
    $('[data-sv-share]', panel).addEventListener('click', share);
    panel.addEventListener('click', function (e) {
      var r = e.target.closest('[data-sv-rm]');
      if (r) { var i = idx(r.getAttribute('data-sv-rm')); if (i > -1) { list.splice(i, 1); save(); sync(); } }
    });
  }
  function el(tag, cls, text) { var n = document.createElement(tag); if (cls) n.className = cls; if (text) n.textContent = text; return n; }
  function render() {
    if (!body) return;
    body.textContent = '';
    if (!list.length) { body.appendChild(el('p', 'ald-sv__e', 'Nothing saved yet. Tap the heart on any jersey to keep it here. Your list is kept on this device.')); foot.hidden = true; return; }
    foot.hidden = false;
    list.forEach(function (x) {
      var url = '/products/' + encodeURIComponent(x.h), row = el('div', 'ald-svi'), a = el('a', 'ald-svi__m'), d = document.createElement('div');
      a.href = url; a.tabIndex = -1; a.setAttribute('aria-hidden', 'true');
      if (x.i) { var im = document.createElement('img'); im.src = x.i; im.alt = x.t; im.loading = 'lazy'; a.appendChild(im); }
      var t = el('a', 'ald-svi__t', x.t), pr = el('span', 'ald-pr'), rm = el('button', 'ald-svi__x', 'Remove');
      t.href = url; pr.appendChild(el('b', '', x.p)); if (x.m) pr.appendChild(el('s', '', x.m));
      rm.type = 'button'; rm.setAttribute('data-sv-rm', x.h);
      d.appendChild(t); d.appendChild(pr); d.appendChild(rm); row.appendChild(a); row.appendChild(d); body.appendChild(row);
    });
  }
  function sync() {
    var on = {};
    list.forEach(function (x) { on[x.h] = 1; });
    $$('[data-sv]').forEach(function (b) {
      var s = !!on[b.getAttribute('data-sv')], sp = $('span', b);
      b.classList.toggle('is-on', s); b.setAttribute('aria-pressed', s);
      if (sp) sp.textContent = s ? 'Saved' : 'Save';
    });
    $$('[data-ald-saved-count]').forEach(function (x) { x.textContent = list.length || ''; x.parentNode.classList.toggle('has-saved', list.length > 0); });
    render();
  }
  function money(c) { return 'Rs. ' + Math.round(c / 100).toLocaleString('en-IN'); }
  function refresh() {
    list.slice().forEach(function (x) {
      fetch('/products/' + encodeURIComponent(x.h) + '.js').then(function (r) {
        if (r.status === 404) { var i = idx(x.h); if (i > -1) { list.splice(i, 1); save(); sync(); } return null; }
        return r.ok ? r.json() : null;
      }).then(function (p) {
        if (!p) return;
        x.p = money(p.price); x.m = p.compare_at_price > p.price ? money(p.compare_at_price) : '';
        save(); render();
      }).catch(function () {});
    });
  }
  function share() {
    var text = 'My POLARSPOT saved list:\n' + list.map(function (x) { return x.t + ' - ' + location.origin + '/products/' + encodeURIComponent(x.h); }).join('\n');
    if (navigator.share) { navigator.share({ title: 'POLARSPOT saved list', text: text }).catch(function () {}); return; }
    window.open('https://wa.me/?text=' + encodeURIComponent(text), '_blank', 'noopener');
  }
  function init() {
    header(); pdp(); build(); decorate(); sync();
    new MutationObserver(function () {
      if (q) return;
      q = 1;
      setTimeout(function () { q = 0; decorate(); pdp(); }, 60);
    }).observe(document.body, { childList: true, subtree: true });
    new MutationObserver(function () {
      if (document.body.getAttribute('data-ald') === 'saved' && !fetched) { fetched = 1; refresh(); }
    }).observe(document.body, { attributes: true, attributeFilter: ['data-ald'] });
    window.addEventListener('storage', function (e) { if (e.key === KEY) { list = load(); sync(); } });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();