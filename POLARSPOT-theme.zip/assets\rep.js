/* ==========================================================================
   POLARSPOT — REP layout behaviour. Runs alongside r-base.js, which handles
   cart, drawers, search and the product form.
   ========================================================================== */
(() => {
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const desktop = window.matchMedia('(min-width: 990px)');
  const designMode = !!(window.Shopify && window.Shopify.designMode);
  const store = {
    get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
    set(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* storage off */ } },
    session(k, v) { try { return v === undefined ? sessionStorage.getItem(k) : sessionStorage.setItem(k, v); } catch (e) { return null; } }
  };

  /* ---------- Scroll reveal ---------- */
  function initReveal(root = document) {
    const els = $$('[data-reveal]', root).filter((el) => !el.classList.contains('is-in'));
    if (!els.length) return;
    if (reduce || designMode || !('IntersectionObserver' in window)) {
      els.forEach((el) => el.classList.add('is-in'));
      return;
    }
    const io = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('is-in');
        io.unobserve(entry.target);
      });
    }, { rootMargin: '0px 0px -6% 0px', threshold: 0.02 });
    els.forEach((el, i) => {
      if (el.parentElement && el.parentElement.children.length > 1) el.style.setProperty('--i', String(i % 8));
      io.observe(el);
    });
  }

  /* ---------- Image fade-in ---------- */
  function initImages(root = document) {
    $$('.r-card__media img, .r-tile img, .r-mega__card img', root).forEach((img) => {
      if (img.complete && img.naturalWidth) img.classList.add('is-loaded');
      else img.addEventListener('load', () => img.classList.add('is-loaded'), { once: true });
    });
  }

  /* ---------- Top bar ---------- */
  function initTopbar(root = document) {
    const bar = $('[data-r-topbar]', root);
    if (!bar) return;
    document.body.classList.add('has-topbar');
    const host = bar.closest('.shopify-section');
    const header = $('.r-header-host');
    if (header) header.classList.add('has-topbar');
    const h = getComputedStyle(bar).getPropertyValue('--r-topbar-h');
    if (h) document.documentElement.style.setProperty('--r-topbar-h', h.trim());

    function hide() {
      bar.hidden = true;
      document.body.classList.remove('has-topbar');
      if (header) header.classList.remove('has-topbar');
      if (host) host.style.display = 'none';
    }
    if (store.session('r-topbar-off') === '1' && !designMode) hide();

    const close = $('[data-r-topbar-close]', bar);
    if (close) close.addEventListener('click', () => { store.session('r-topbar-off', '1'); hide(); });

    const pause = $('[data-r-topbar-pause]', bar);
    if (pause) {
      pause.addEventListener('click', () => {
        const paused = bar.classList.toggle('is-paused');
        pause.setAttribute('aria-pressed', String(paused));
        pause.setAttribute('aria-label', paused ? 'Play announcements' : 'Pause announcements');
      });
    }
  }

  /* ---------- Promo modal ---------- */
  const Modal = {
    open(el) {
      if (!el) return;
      el.classList.add('is-open');
      document.body.classList.add('is-locked');
      el._last = document.activeElement;
      const first = $('[data-r-modal-close]', el);
      setTimeout(() => first && first.focus({ preventScroll: true }), 80);
    },
    close(el) {
      if (!el) return;
      el.classList.remove('is-open');
      if (!$('.drawer.is-open')) document.body.classList.remove('is-locked');
      if (el._last && el._last.focus) el._last.focus({ preventScroll: true });
    }
  };
  function initModal(root = document) {
    const el = $('[data-r-promo]', root);
    if (!el || el._wired) return;
    el._wired = true;
    const key = el.dataset.key || 'r-promo';
    const days = Number(el.dataset.days) || 14;
    const delay = (Number(el.dataset.delay) || 0) * 1000;

    if (el.dataset.designMode === 'true') { Modal.open(el); return; }
    const until = Number(store.get(key) || 0);
    if (until && Date.now() < until) return;

    setTimeout(() => { if (!$('.drawer.is-open')) Modal.open(el); }, delay);

    const remember = () => store.set(key, String(Date.now() + days * 864e5));
    el.addEventListener('click', (e) => { if (e.target.closest('[data-r-modal-close]')) remember(); });
    const form = $('form', el);
    if (form) form.addEventListener('submit', remember);
  }
  document.addEventListener('click', (e) => {
    const closer = e.target.closest('[data-r-modal-close]');
    if (closer) { e.preventDefault(); Modal.close(closer.closest('[data-r-modal]')); }
  });
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    const open = $('[data-r-modal].is-open');
    if (open) Modal.close(open);
  });

  /* ---------- Header: transparent → solid, mega menus ---------- */
  function initHeader(root = document) {
    const header = $('[data-r-header]', root);
    if (!header) return;
    const host = header.closest('.shopify-section');
    if (host) host.classList.toggle('is-overlay', header.classList.contains('is-transparent'));

    if (header.classList.contains('is-transparent')) {
      const onScroll = () => header.classList.toggle('is-solid', window.scrollY > 24);
      onScroll();
      window.addEventListener('scroll', onScroll, { passive: true });
    }

    const tabs = $$('[data-r-tab]', header);
    const closeAll = (except) => {
      tabs.forEach((t) => {
        if (t === except) return;
        t.classList.remove('is-open');
        const a = t.firstElementChild; if (a) a.setAttribute('aria-expanded', 'false');
      });
      header.classList.toggle('has-open', !!except);
    };
    tabs.forEach((tab) => {
      let timer;
      const open = () => {
        if (!desktop.matches) return;
        clearTimeout(timer);
        closeAll(tab);
        tab.classList.add('is-open');
        tab.firstElementChild.setAttribute('aria-expanded', 'true');
      };
      const close = () => { timer = setTimeout(() => closeAll(null), 160); };
      tab.addEventListener('mouseenter', open);
      tab.addEventListener('mouseleave', close);
      tab.addEventListener('focusin', open);
      tab.addEventListener('focusout', (e) => { if (!tab.contains(e.relatedTarget)) close(); });
    });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeAll(null); });
  }

  /* ---------- Mobile drill-down menu ---------- */
  function initDrill(root = document) {
    const stage = $('[data-r-stage]', root);
    if (!stage || stage._wired) return;
    stage._wired = true;
    const levels = $$('.r-mnav__level', stage);
    const rootLevel = $('[data-root]', stage);
    let stack = [];

    const paint = (focus) => {
      const current = stack.length ? document.getElementById(stack[stack.length - 1]) : rootLevel;
      levels.forEach((lv) => {
        lv.classList.remove('is-active', 'is-past');
        const inStack = stack.indexOf(lv.id) > -1;
        if (lv === current) lv.classList.add('is-active');
        else if (inStack || (lv === rootLevel && stack.length)) lv.classList.add('is-past');
      });
      if (current) {
        current.scrollTop = 0;
        if (focus) { const f = $('a,button', current); if (f) f.focus({ preventScroll: true }); }
      }
    };

    stage.addEventListener('click', (e) => {
      const go = e.target.closest('[data-r-go]');
      if (go) { e.preventDefault(); stack.push(go.dataset.rGo); paint(true); return; }
      if (e.target.closest('[data-r-back]')) { e.preventDefault(); stack.pop(); paint(true); }
    });

    const drawer = stage.closest('[data-drawer]');
    if (drawer) {
      new MutationObserver(() => {
        if (!drawer.classList.contains('is-open') && stack.length) { stack = []; paint(false); }
      }).observe(drawer, { attributes: true, attributeFilter: ['class'] });
    }
  }

  /* ---------- Wishlist ---------- */
  const SAVE_KEY = 'r-saved';
  const readSaved = () => { try { return JSON.parse(store.get(SAVE_KEY)) || []; } catch (e) { return []; } };
  const writeSaved = (list) => store.set(SAVE_KEY, JSON.stringify(list));
  function paintSaved(root = document) {
    const saved = readSaved();
    $$('[data-r-save]', root).forEach((b) => b.setAttribute('aria-pressed', String(saved.includes(b.dataset.rSave))));
    $$('[data-r-wish-count]').forEach((el) => { el.dataset.count = saved.length; el.textContent = saved.length ? saved.length : ''; });
    $$('[data-r-wish-total]').forEach((el) => { el.textContent = saved.length; });
  }
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-r-save]');
    if (!btn) return;
    e.preventDefault(); e.stopPropagation();
    const handle = btn.dataset.rSave;
    let saved = readSaved();
    const had = saved.includes(handle);
    saved = had ? saved.filter((h) => h !== handle) : saved.concat(handle);
    writeSaved(saved);
    paintSaved();
    if (window.PS && window.PS.toast) window.PS.toast(had ? 'Removed from wishlist' : 'Saved to wishlist');
    if ($('[data-r-wish-page]') && had) renderWishlist();
  }, true);

  async function renderWishlist() {
    const page = $('[data-r-wish-page]');
    if (!page) return;
    const grid = $('[data-r-wish-grid]', page);
    const empty = $('[data-r-wish-empty]', page);
    const handles = readSaved();
    if (!handles.length) { grid.hidden = true; grid.innerHTML = ''; empty.hidden = false; return; }
    empty.hidden = true;
    grid.hidden = false;
    grid.innerHTML = handles.map(() => '<li><div class="r-card"><div class="r-card__media r-skel"></div><div class="r-card__info"><span class="r-skel" style="height:12px;width:70%"></span></div></div></li>').join('');
    const base = page.dataset.urlBase || '/';
    const cards = await Promise.all(handles.map(async (h) => {
      try {
        const res = await fetch(base + 'products/' + h + '?view=r-card', { headers: { 'X-Requested-With': 'XMLHttpRequest' } });
        if (!res.ok) throw new Error('missing');
        const html = (await res.text()).trim();
        return html.indexOf('r-card') > -1 ? '<li>' + html + '</li>' : '';
      } catch (e) { return ''; }
    }));
    const out = cards.filter(Boolean).join('');
    if (!out) { grid.hidden = true; grid.innerHTML = ''; empty.hidden = false; return; }
    grid.innerHTML = out;
    initImages(grid);
    initReveal(grid);
    paintSaved(grid);
  }

  /* ---------- Footer accordions ---------- */
  function initFooter() {
    const sync = () => $$('[data-r-footer-acc]').forEach((d) => { d.open = desktop.matches; });
    sync();
    desktop.addEventListener('change', sync);
  }

  /* ---------- Collection: model switch + load more ---------- */
  function initCollection(root = document) {
    const sw = $('[data-r-model]', root);
    if (sw && !sw._wired) {
      sw._wired = true;
      const set = (v) => {
        sw.setAttribute('aria-checked', String(v));
        document.body.classList.toggle('r-show-model', v);
        store.session('r-model', v ? '1' : '0');
      };
      set(store.session('r-model') === '1');
      sw.addEventListener('click', () => set(sw.getAttribute('aria-checked') !== 'true'));
    }

    $$('[data-r-more]', root).forEach((btn) => {
      if (btn._wired) return;
      btn._wired = true;
      btn.addEventListener('click', async (e) => {
        e.preventDefault();
        const grid = $('[data-r-grid]');
        if (!grid || btn.classList.contains('is-loading')) return;
        btn.classList.add('is-loading');
        try {
          const res = await fetch(btn.href);
          const doc = new DOMParser().parseFromString(await res.text(), 'text/html');
          const fresh = $('[data-r-grid]', doc);
          if (fresh) {
            const added = Array.from(fresh.children);
            grid.append(...added);
            added.forEach((li) => initReveal(li));
            initImages(grid);
            paintSaved(grid);
          }
          const nextBtn = $('[data-r-more]', doc);
          const viewing = $('[data-r-viewing]', doc);
          const prog = $('[data-r-progress]', doc);
          if (viewing && $('[data-r-viewing]')) $('[data-r-viewing]').textContent = viewing.textContent;
          if (prog && $('[data-r-progress]')) $('[data-r-progress]').style.width = prog.style.width;
          if (nextBtn) { btn.href = nextBtn.href; window.history.replaceState({}, '', btn.href); }
          else btn.remove();
        } catch (err) {
          window.location.href = btn.href;
        } finally {
          btn.classList.remove('is-loading');
        }
      });
    });
  }

  /* ---------- Product gallery ---------- */
  function initGallery(root = document) {
    $$('[data-r-gallery]', root).forEach((gal) => {
      if (gal._wired) return;
      gal._wired = true;
      const track = $('[data-r-track]', gal);
      const slides = $$('.r-gal__slide', track);
      const count = $('[data-r-count]', gal);
      const thumbs = $$('[data-r-thumb]', gal);
      const total = slides.length;
      const index = () => Math.round(track.scrollLeft / Math.max(1, track.clientWidth));
      const go = (i) => {
        const n = (i + total) % total;
        track.scrollTo({ left: n * track.clientWidth, behavior: reduce ? 'auto' : 'smooth' });
      };
      const sync = () => {
        const i = index();
        if (count) count.textContent = (i + 1) + ' / ' + total;
        thumbs.forEach((t) => t.setAttribute('aria-current', String(Number(t.dataset.rThumb) === i)));
      };
      track.addEventListener('scroll', sync, { passive: true });
      thumbs.forEach((t) => t.addEventListener('click', () => go(Number(t.dataset.rThumb))));
      const prev = $('[data-r-prev]', gal);
      const next = $('[data-r-next]', gal);
      if (prev) prev.addEventListener('click', () => go(index() - 1));
      if (next) next.addEventListener('click', () => go(index() + 1));
      gal.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowLeft') go(index() - 1);
        if (e.key === 'ArrowRight') go(index() + 1);
      });

      const section = gal.closest('[data-r-pdp]');
      const json = section && $('[data-product-json]', section);
      if (section && json) {
        const data = JSON.parse(json.textContent);
        section.addEventListener('change', (e) => {
          if (!e.target.matches('[data-option-value]')) return;
          const sel = $$('[data-option]', section).map((fs) => { const c = $('input:checked', fs); return c ? c.value : null; });
          const v = data.variants.find((x) => x.options.every((o, i) => sel[i] === null || o === sel[i]));
          if (!v || !v.media_id) return;
          const i = slides.findIndex((sl) => sl.dataset.mediaId === String(v.media_id));
          if (i >= 0) go(i);
        });
      }
    });

    const zoom = $('[data-r-zoom]');
    if (zoom && !zoom._wired) {
      zoom._wired = true;
      document.addEventListener('click', (e) => {
        if (e.target.closest('[data-r-zoom-open]')) {
          zoom.classList.add('is-open'); document.body.classList.add('is-locked');
          const c = $('[data-r-zoom-close]', zoom); if (c) c.focus();
        }
        if (e.target.closest('[data-r-zoom-close]')) { zoom.classList.remove('is-open'); document.body.classList.remove('is-locked'); }
      });
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && zoom.classList.contains('is-open')) { zoom.classList.remove('is-open'); document.body.classList.remove('is-locked'); }
      });
    }

    $$('[data-add-label]', root).forEach((label) => {
      if (label._wired) return;
      label._wired = true;
      const copy = label.parentElement.querySelector('[data-add-label-copy]');
      if (!copy) return;
      new MutationObserver(() => { copy.textContent = label.textContent; }).observe(label, { childList: true, characterData: true, subtree: true });
    });
    $$('[data-sticky-add]', root).forEach((btn) => {
      if (btn._wired) return;
      btn._wired = true;
      new MutationObserver(() => {
        if (!btn.querySelector('.r-btn__t')) { const t = btn.textContent; btn.innerHTML = '<span class="r-btn__t">' + t + '</span>'; }
      }).observe(btn, { childList: true });
    });
  }

  /* ---------- Quantity selector ---------- */
  function initQty(root = document) {
    $$('[data-r-qty]', root).forEach((box) => {
      if (box._wired) return;
      box._wired = true;
      const input = $('[data-r-qty-input]', box);
      if (!input) return;
      const clamp = () => {
        let n = parseInt(input.value, 10);
        if (!n || n < 1) n = 1;
        input.value = n;
        const minus = $('[data-r-qty-step="-1"]', box);
        if (minus) minus.disabled = n <= 1;
      };
      $$('[data-r-qty-step]', box).forEach((b) => b.addEventListener('click', () => {
        input.value = Math.max(1, (parseInt(input.value, 10) || 1) + Number(b.dataset.rQtyStep));
        clamp();
      }));
      input.addEventListener('change', clamp);
      clamp();
    });
  }

  /* ---------- Reviews ---------- */
  function initReviews(root = document) {
    const list = $('[data-r-rev-list]', root);
    if (!list || list._wired) return;
    list._wired = true;
    const items = $$('.r-review', list);
    const pager = $('[data-r-rev-pager]', root);
    const search = $('[data-r-rev-search]', root);
    const sort = $('[data-r-rev-sort]', root);
    const per = Number(list.dataset.per) || 5;
    let page = 0;
    const render = () => {
      const q = (search && search.value.trim().toLowerCase()) || '';
      const rows = items.filter((r) => !q || r.textContent.toLowerCase().includes(q));
      const mode = sort ? sort.value : 'new';
      rows.sort((a, b) => mode === 'high' ? b.dataset.stars - a.dataset.stars : mode === 'low' ? a.dataset.stars - b.dataset.stars : (b.dataset.date || 0) - (a.dataset.date || 0));
      items.forEach((r) => { r.hidden = true; });
      rows.forEach((r, i) => { list.append(r); r.hidden = q ? false : Math.floor(i / per) !== page; });
      if (pager) {
        pager.hidden = !!q;
        $$('button', pager).forEach((b) => b.setAttribute('aria-current', String(Number(b.dataset.page) === page)));
      }
    };
    if (pager) pager.addEventListener('click', (e) => { const b = e.target.closest('button'); if (b) { page = Number(b.dataset.page); render(); } });
    if (search) search.addEventListener('input', render);
    if (sort) sort.addEventListener('change', () => { page = 0; render(); });
    render();
  }

  /* ---------- You may also like ---------- */
  function initAlso(root = document) {
    $$('[data-r-also]', root).forEach((sec) => {
      if (sec._wired) return;
      sec._wired = true;
      const tabs = $$('[data-r-also-tab]', sec);
      const more = $('[data-r-also-more]', sec);
      const step = desktop.matches ? 5 : 4;
      let visible = step;
      const panel = () => { const t = tabs.find((x) => x.getAttribute('aria-selected') === 'true'); return t && document.getElementById(t.getAttribute('aria-controls')); };
      const apply = () => {
        const p = panel();
        if (!p) return;
        const cards = $$('[data-r-also-grid] > li', p);
        cards.forEach((li, i) => { li.hidden = i >= visible; });
        if (more) more.parentElement.hidden = cards.length <= visible;
        initImages(p);
      };
      tabs.forEach((t) => t.addEventListener('click', () => {
        tabs.forEach((x) => {
          const on = x === t;
          x.setAttribute('aria-selected', String(on));
          const p = document.getElementById(x.getAttribute('aria-controls'));
          if (p) p.hidden = !on;
        });
        visible = step;
        apply();
      }));
      if (more) more.addEventListener('click', () => { visible += step * 2; apply(); });
      const first = $('[data-recommendations]', sec);
      if (first) new MutationObserver(() => { apply(); paintSaved(sec); }).observe(first, { childList: true });
      apply();
    });
  }

  /* ---------- Account helpers ---------- */
  function initAccount(root = document) {
    const toggles = $$('[data-r-auth-toggle]', root);
    const login = $('#LoginForm');
    const recover = $('#RecoverPassword');
    if (toggles.length && login && recover) {
      const swap = () => {
        const showRecover = recover.style.display === 'none';
        recover.style.display = showRecover ? 'block' : 'none';
        login.style.display = showRecover ? 'none' : 'block';
        const focusOn = showRecover ? $('#RecoverEmail') : $('#LoginEmail');
        if (focusOn) focusOn.focus({ preventScroll: true });
      };
      toggles.forEach((t) => { if (!t._wired) { t._wired = true; t.addEventListener('click', swap); } });
      if (window.location.hash === '#recover') swap();
    }
    $$('[data-r-addr-edit]', root).forEach((b) => {
      if (b._wired) return;
      b._wired = true;
      b.addEventListener('click', () => {
        const box = document.getElementById('RAddr-' + b.dataset.rAddrEdit);
        if (box) box.hidden = !box.hidden;
      });
    });
    if (window.Shopify && window.Shopify.CountryProvinceSelector) {
      $$('select[name="address[country]"]', root).forEach((sel) => {
        if (sel._wired) return;
        sel._wired = true;
        const id = sel.id;
        const prov = id.replace('-country', '-province');
        try { new window.Shopify.CountryProvinceSelector(id, prov, { hideElement: prov + '-wrap' }); } catch (e) { /* ignore */ }
      });
    }
  }
  document.addEventListener('submit', (e) => {
    const btn = e.submitter;
    if (btn && btn.dataset.confirm && !window.confirm(btn.dataset.confirm)) e.preventDefault();
  });

  /* ---------- Back to top ---------- */
  function initTop() {
    if ($('.r-top')) return;
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'r-top';
    btn.setAttribute('aria-label', 'Back to top');
    btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20V5M7 10l5-5 5 5"/></svg>';
    btn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: reduce ? 'auto' : 'smooth' }));
    document.body.appendChild(btn);
    const onScroll = () => btn.classList.toggle('is-visible', window.scrollY > window.innerHeight);
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  /* ---------- Boot ---------- */
  function init(root = document) {
    initHeader(root);
    initDrill(root);
    initTopbar(root);
    initModal(root);
    initCollection(root);
    initGallery(root);
    initQty(root);
    initReviews(root);
    initAlso(root);
    initAccount(root);
    initImages(root);
    initReveal(root);
    paintSaved(root);
  }
  const boot = () => {
    init();
    initFooter();
    initTop();
    renderWishlist();
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();

  document.addEventListener('shopify:section:load', (e) => init(e.target));
  document.addEventListener('ps:cart-updated', () => paintSaved());

  window.PS = window.PS || {};
  window.PS.wishlist = { read: readSaved, render: renderWishlist };
})();
