/* Core storefront behaviour: open/close state on <body data-ald>, cart (Ajax API + section rendering),
   product options, quick add, sticky buy bar, recommendations, filters and infinite load.
   Every listener is delegated from document so re-rendered markup keeps working and nothing binds twice. */
(function () {
  if (window.__ald) return;
  window.__ald = true;
  var A = window.ALD || {}, B = document.body;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  function set(v) { B.setAttribute('data-ald', v || ''); $$('[data-ald-open=menu]').forEach(function (m) { m.setAttribute('aria-expanded', v === 'menu'); }); }
  function get() { return B.getAttribute('data-ald') || ''; }

  document.addEventListener('click', function (e) {
    /* a link inside an open drawer to a spot on this page: close first, then scroll (otherwise the page stays locked) */
    var ml = e.target.closest('.ps-drawer a[href], .ald-srch a[href]');
    if (ml) {
      try {
        var u = new URL(ml.href, location.href);
        if (u.origin === location.origin && u.pathname === location.pathname && u.hash.length > 1) {
          var tg = document.getElementById(decodeURIComponent(u.hash.slice(1)));
          if (tg) { e.preventDefault(); set(''); setTimeout(function () { tg.scrollIntoView({ behavior: 'smooth', block: 'start' }); tg.focus({ preventScroll: true }); }, 60); }
        }
      } catch (x) {}
      return;
    }
    var o = e.target.closest('[data-ald-open]');
    if (o) { e.preventDefault(); var v = o.getAttribute('data-ald-open'); set(get() === v ? '' : v); return; }
    if (e.target.closest('[data-ald-close]')) { set(''); return; }
    var ac = e.target.closest('[data-ald-acc]');
    if (ac) { var p = ac.parentNode, on = p.classList.toggle('is-open'); ac.setAttribute('aria-expanded', on); return; }
    var q = e.target.closest('[data-ald-q]');
    if (q) { e.preventDefault(); change(q.getAttribute('data-key'), +q.getAttribute('data-ald-q')); return; }
    var qa = e.target.closest('[data-ald-qa-id]');
    if (qa) { e.preventDefault(); if (!qa.disabled) quick(qa); return; }
    var fl = e.target.closest('.ald-fl>button');
    if (fl) { var on2 = fl.parentNode.classList.toggle('is-open'); fl.setAttribute('aria-expanded', on2); }
  });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && get()) set(''); });

  /* ---------- cart ---------- */
  function render(html) {
    var d = new DOMParser().parseFromString(html, 'text/html'), n = $('.shopify-section', d) || d.body, c = $('#shopify-section-ald-cart-drawer');
    if (c && n) c.innerHTML = n.innerHTML;
    var cnt = $('[data-ald-cart-count]', c || document), val = cnt ? cnt.getAttribute('data-ald-cart-count') : '';
    $$('[data-ald-count]').forEach(function (x) { x.textContent = +val > 0 ? val : ''; });
  }
  function refresh() {
    return fetch(A.root + '?sections=ald-cart-drawer').then(function (r) { return r.json(); }).then(function (j) { render(j['ald-cart-drawer']); });
  }
  function change(key, qty) {
    return fetch(A.cartChange, { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify({ id: key, quantity: Math.max(0, qty) }) })
      .then(function (r) { if (!r.ok) throw 0; }).then(refresh).catch(refresh);
  }
  /* resolves true on success; the drawer opens so the shopper sees what was added */
  function add(id, btn, err) {
    if (btn) btn.setAttribute('aria-busy', 'true');
    if (err) err.textContent = '';
    return fetch(A.cartAdd, { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify({ items: [{ id: +id, quantity: 1 }] }) })
      .then(function (r) { return r.json().then(function (j) { if (!r.ok) throw j; return j; }); })
      .then(refresh).then(function () { set('cart'); return true; })
      .catch(function (j) { if (err) err.textContent = (j && j.description) || A.err; return false; })
      .then(function (ok) { if (btn) btn.removeAttribute('aria-busy'); return ok; });
  }
  A.add = add;
  function quick(b) {
    var card = b.closest('.ald-card');
    add(b.getAttribute('data-ald-qa-id'), b, null).then(function (ok) {
      if (!ok && card) { var n = card.querySelector('.ald-qa p'); if (n) n.textContent = A.err; }
    });
  }

  /* ---------- product options ---------- */
  var wrap = $('[data-ald-buy]');
  if (wrap) {
    var V = JSON.parse($('[data-ald-variants]').textContent);
    var form = $('form', wrap), btn = $('[data-ald-atb]', wrap), vid = $('[data-ald-vid]', wrap), msg = $('[data-ald-msg]', wrap), err = $('[data-ald-err]', wrap);
    var groups = $$('[data-ald-opt]', wrap), one = wrap.hasAttribute('data-single');
    var sticky = $('[data-ald-sticky]'), sbtn = sticky && $('[data-ald-sticky-btn]', sticky);
    var sel = groups.map(function (g) { var c = $('input:checked', g); return c ? c.value : null; });
    function match(pos, val) {
      return V.filter(function (v) { return v.a && v.o[pos] === val && v.o.every(function (o, i) { return i === pos || !sel[i] || sel[i] === o; }); });
    }
    function current() {
      if (one) return V[0];
      if (!sel.every(Boolean)) return null;
      return V.filter(function (x) { return x.o.join('|') === sel.join('|'); })[0] || null;
    }
    function label(t) { btn.textContent = t; if (sbtn) sbtn.textContent = t; }
    function sync(fromUser) {
      groups.forEach(function (g, i) {
        $$('input', g).forEach(function (r) {
          var ok = match(i, r.value).length > 0;
          r.disabled = !ok;
          r.parentNode.title = ok ? '' : A.soldOut;
          if (!ok && r.checked) { r.checked = false; sel[i] = null; }
        });
        var vt = $('[data-ald-opt-v]', g);
        if (vt) vt.innerHTML = sel[i] ? ': <b></b>' : '';
        if (vt && sel[i]) vt.querySelector('b').textContent = sel[i];
      });
      var v = current();
      if (v) {
        vid.value = v.id;
        $$('[data-ald-price]').forEach(function (p) { p.textContent = v.p; });
        var mrp = $('[data-ald-mrp]'), pct = $('[data-ald-pct]');
        if (mrp) { mrp.hidden = !v.c; if (v.c) mrp.lastElementChild.textContent = v.c; }
        if (pct) { pct.hidden = !v.d; pct.textContent = v.d + '% off'; }
        if (fromUser && !one) history.replaceState(null, '', location.pathname + '?variant=' + v.id);
      }
      var avail = !!(v && v.a), anyAvail = V.some(function (x) { return x.a; });
      btn.disabled = !anyAvail || (!!v && !v.a);
      label(!anyAvail ? A.soldOut : !v ? A.pick : avail ? A.addBag : A.soldOut);
      if (msg) msg.textContent = v && v.a && v.q ? A.only.replace('{n}', v.q).replace('{v}', v.o.join(' / ')) : '';
      if (err && fromUser) err.textContent = '';
    }
    groups.forEach(function (g, i) {
      g.addEventListener('change', function (e) { if (e.target.name) { sel[i] = e.target.value; sync(true); } });
    });
    function firstMissing() { for (var i = 0; i < groups.length; i++) if (!sel[i]) return groups[i]; return null; }
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var miss = firstMissing();
      if (miss) { var r = $('input:not(:disabled)', miss); if (r) r.focus(); if (err) err.textContent = A.pick + '.'; return; }
      if (!btn.disabled) add(vid.value, btn, err);
    });
    /* while sizes are missing the main button stays clickable and explains what is needed */
    sync(false);

    /* sticky bar (phones): visible once the main button has scrolled out of view, never over it */
    if (sticky && sbtn && 'IntersectionObserver' in window) {
      var seen = true;
      new IntersectionObserver(function (en) {
        seen = en[0].isIntersecting || en[0].boundingClientRect.top > window.innerHeight;
        var on = !seen && !btn.disabled;
        sticky.classList.toggle('is-on', on);
        sticky.setAttribute('aria-hidden', !on);
        sbtn.tabIndex = on ? 0 : -1;
      }).observe(btn);
      sbtn.addEventListener('click', function () {
        var miss = firstMissing();
        if (miss) { miss.scrollIntoView({ behavior: 'smooth', block: 'center' }); var r = $('input:not(:disabled)', miss); if (r) setTimeout(function () { r.focus({ preventScroll: true }); }, 350); return; }
        add(vid.value, sbtn, err);
      });
    }
  }

  /* ---------- recommendations ---------- */
  var rec = $('[data-ald-recs]');
  if (rec) fetch(rec.getAttribute('data-url')).then(function (r) { return r.text(); }).then(function (h) {
    var n = $('[data-ald-recs-in]', new DOMParser().parseFromString(h, 'text/html'));
    if (n && n.children.length) { rec.innerHTML = n.innerHTML; rec.hidden = false; }
  }).catch(function () {});

  /* ---------- collection: apply filters, infinite load ---------- */
  var ff = $('[data-ald-filters]');
  function submitFilters() { $$('input[type=number]', ff).forEach(function (i) { if (!i.value) i.disabled = true; }); ff.submit(); }
  if (ff) ff.addEventListener('submit', function (e) { e.preventDefault(); submitFilters(); });
  var grid = $('[data-ald-grid]'), busy = false;
  function more() {
    var nx = $('[data-ald-next]'); if (!nx || busy || !grid) return; busy = true;
    nx.setAttribute('aria-busy', 'true');
    fetch(nx.href).then(function (r) { return r.text(); }).then(function (h) {
      var d = new DOMParser().parseFromString(h, 'text/html'), g = $('[data-ald-grid]', d), n2 = $('[data-ald-next]', d);
      if (g) Array.prototype.slice.call(g.children).forEach(function (c) { grid.appendChild(document.importNode(c, true)); });
      if (n2) { nx.href = n2.href; nx.removeAttribute('aria-busy'); } else nx.remove();
      busy = false;
    }).catch(function () { busy = false; nx.removeAttribute('aria-busy'); });
  }
  var nx0 = $('[data-ald-next]');
  if (nx0) {
    nx0.addEventListener('click', function (e) { e.preventDefault(); more(); });
    if ('IntersectionObserver' in window) new IntersectionObserver(function (en) { if (en[0].isIntersecting) more(); }, { rootMargin: '600px' }).observe(nx0);
  }
})()