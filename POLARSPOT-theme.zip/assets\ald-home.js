/* Reveal the header once the visitor leaves the vault gate (Enter or scroll); hide it again back at the very top. */
(function () {
  var b = document.body;
  if (!b.classList.contains('template-index')) return;
  function u() { b.classList.toggle('ald-pre', (window.scrollY || document.documentElement.scrollTop || 0) < 24); }
  window.addEventListener('scroll', u, { passive: true });
  window.addEventListener('pageshow', u);
  var a = document.querySelector('[data-ald-enter]');
  if (a) a.addEventListener('click', function () { b.classList.remove('ald-pre'); });
  u();
  setTimeout(u, 150);
})();
