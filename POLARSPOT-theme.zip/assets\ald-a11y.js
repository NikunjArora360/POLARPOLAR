/* Focus, scroll lock and background isolation for the drawers, panels and search. */
(function () {
  'use strict';
  var B = document.body, R = document.documentElement, main = document.getElementById('MainContent'), last = null, held = [];
  var FOCUS = { menu: '.ald-menu [data-ald-close]', search: '.ald-srch input[type=search]', cart: '.ald-cart [data-ald-close]', saved: '.ald-sv [data-ald-close]', sort: '.ald-pnl--sort [data-ald-close]', refine: '.ald-pnl--refine [data-ald-close]' };
  var PANEL = { sort: '.ald-pnl--sort', refine: '.ald-pnl--refine' };

  /* reserve the scrollbar width while the page is locked so nothing shifts sideways */
  function measure() {
    if (!B.getAttribute('data-ald')) R.style.setProperty('--sbw', (window.innerWidth - R.clientWidth) + 'px');
  }

  /* everything behind the open layer becomes inert: no tabbing into the page, no reading it aloud */
  function release() {
    held.forEach(function (el) { el.removeAttribute('inert'); });
    held = [];
  }
  function hold(v) {
    release();
    if (!main || !v) return;
    var panel = PANEL[v] ? document.querySelector(PANEL[v]) : null;
    if (!panel || !main.contains(panel)) { main.setAttribute('inert', ''); held.push(main); return; }
    for (var p = panel; p && p !== main; p = p.parentNode) {
      Array.prototype.forEach.call(p.parentNode.children, function (c) {
        if (c !== p) { c.setAttribute('inert', ''); held.push(c); }
      });
    }
  }

  document.addEventListener('click', function (e) {
    var o = e.target.closest('[data-ald-open]');
    if (o) { last = o; measure(); }
  }, true);

  new MutationObserver(function () {
    var v = B.getAttribute('data-ald') || '';
    hold(v);
    if (v) {
      if (!last && document.activeElement && document.activeElement !== B) last = document.activeElement;
      if (FOCUS[v]) setTimeout(function () {
        var t = document.querySelector(FOCUS[v]);
        if (t && t.focus) t.focus({ preventScroll: true });
      }, 120);
    } else {
      if (last && last.focus) last.focus({ preventScroll: true });
      last = null;
      measure();
    }
  }).observe(B, { attributes: true, attributeFilter: ['data-ald'] });

  /* coming back with the browser's back button must never restore an open drawer */
  window.addEventListener('pageshow', function (e) {
    if (e.persisted || B.getAttribute('data-ald')) { B.setAttribute('data-ald', ''); release(); measure(); }
  });

  window.addEventListener('resize', measure, { passive: true });
  measure();
})();