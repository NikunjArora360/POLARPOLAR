/* ==========================================================================
   POLARSPOT REP — base behaviour (cart, drawers, search, product form). No dependencies.
   ========================================================================== */
(() => {
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const PS = window.PS || {};
  PS.routes = PS.routes || {};
  PS.strings = PS.strings || {};
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- Money ---------- */
  function formatMoney(cents, format = PS.moneyFormat || '₹{{amount}}') {
    cents = Math.max(0, Math.round(Number(cents) || 0));
    const whole = cents % 100 === 0;
    const fmt = (decimals, thousands = ',', decimal = '.') => {
      const [int, frac] = (cents / 100).toFixed(decimals).split('.');
      const i = int.replace(/\B(?=(\d{3})+(?!\d))/g, thousands);
      return frac ? i + decimal + frac : i;
    };
    return format.replace(/\{\{\s*(\w+)\s*\}\}/, (_, key) => {
      switch (key) {
        case 'amount_no_decimals': return fmt(0);
        case 'amount_with_comma_separator': return fmt(whole ? 0 : 2, '.', ',');
        case 'amount_no_decimals_with_comma_separator': return fmt(0, '.', ',');
        case 'amount_with_apostrophe_separator': return fmt(whole ? 0 : 2, "'", '.');
        case 'amount_with_space_separator': return fmt(whole ? 0 : 2, ' ', ',');
        default: return fmt(whole ? 0 : 2);
      }
    });
  }

  /* ---------- Toast ---------- */
  let toastTimer;
  function toast(message) {
    const el = $('[data-toast]');
    if (!el || !message) return;
    el.textContent = message;
    el.classList.add('is-visible');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove('is-visible'), 2800);
  }

  /* ---------- Focus trap ---------- */
  const FOCUSABLE = 'a[href], button:not([disabled]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';
  function trapFocus(event, container) {
    if (!container) return;
    const items = $$(FOCUSABLE, container).filter((el) => el.offsetParent !== null);
    if (!items.length) return;
    const first = items[0];
    const last = items[items.length - 1];
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  }

  /* ---------- Drawers ---------- */
  const Drawer = {
    active: null,
    lastFocus: null,
    open(el, trigger) {
      if (!el) return;
      if (Search.isOpen()) Search.close(false);
      if (this.active && this.active !== el) this.close(this.active, false);
      this.lastFocus = trigger || document.activeElement;
      el.classList.add('is-open');
      el.setAttribute('aria-hidden', 'false');
      document.body.classList.add('is-locked');
      $$(`[aria-controls="${el.id}"]`).forEach((b) => b.setAttribute('aria-expanded', 'true'));
      this.active = el;
      const target = $('.drawer__panel [data-drawer-close]', el) || $(FOCUSABLE, $('.drawer__panel', el));
      setTimeout(() => target && target.focus({ preventScroll: true }), 60);
    },
    close(el = this.active, restoreFocus = true) {
      if (!el) return;
      el.classList.remove('is-open');
      el.setAttribute('aria-hidden', 'true');
      $$(`[aria-controls="${el.id}"]`).forEach((b) => b.setAttribute('aria-expanded', 'false'));
      if (this.active === el) this.active = null;
      if (!this.active && !Search.isOpen()) document.body.classList.remove('is-locked');
      if (restoreFocus && this.lastFocus && this.lastFocus.focus) this.lastFocus.focus({ preventScroll: true });
    }
  };

  /* ---------- Search overlay + predictive results ---------- */
  const Search = (() => {
    const el = $('[data-search-overlay]');
    if (!el) return { isOpen: () => false, close() {}, open() {} };
    const input = $('[data-search-input]', el);
    const results = $('[data-predictive-results]', el);
    let trigger = null;
    let timer;
    let controller;

    const api = {
      isOpen: () => el.classList.contains('is-open'),
      open(from) {
        trigger = from;
        if (Drawer.active) Drawer.close(Drawer.active, false);
        el.classList.add('is-open');
        el.setAttribute('aria-hidden', 'false');
        document.body.classList.add('is-locked');
        setTimeout(() => input && input.focus(), 80);
      },
      close(restore = true) {
        el.classList.remove('is-open');
        el.setAttribute('aria-hidden', 'true');
        if (!Drawer.active) document.body.classList.remove('is-locked');
        if (restore && trigger && trigger.focus) trigger.focus({ preventScroll: true });
      }
    };

    if (input && results && el.dataset.predictive === 'true' && PS.routes.predictiveSearch) {
      input.addEventListener('input', () => {
        clearTimeout(timer);
        const q = input.value.trim();
        if (!q) { results.innerHTML = ''; return; }
        timer = setTimeout(async () => {
          if (controller) controller.abort();
          controller = new AbortController();
          try {
            const url = `${PS.routes.predictiveSearch}?q=${encodeURIComponent(q)}&resources[type]=product,collection,query&resources[limit]=4&resources[options][prefix]=last&section_id=r-predictive-search`;
            const res = await fetch(url, { signal: controller.signal });
            if (!res.ok) throw new Error(res.statusText);
            const doc = new DOMParser().parseFromString(await res.text(), 'text/html');
            const section = doc.querySelector('#shopify-section-r-predictive-search');
            results.innerHTML = section ? section.innerHTML : '';
          } catch (err) {
            if (err.name !== 'AbortError') results.innerHTML = '';
          }
        }, 220);
      });
    }

    el.addEventListener('keydown', (e) => { if (e.key === 'Tab') trapFocus(e, $('.search-overlay__panel', el)); });
    return api;
  })();

  /* ---------- Cart ---------- */
  const Cart = {
    drawer: () => $('[data-cart-drawer]'),
    sectionIds() {
      const ids = [];
      if (this.drawer()) ids.push('r-cart-drawer');
      return ids;
    },
    async add(payload, trigger) {
      const ids = this.sectionIds();
      let options;
      if (payload instanceof FormData) {
        if (ids.length) { payload.append('sections', ids.join(',')); payload.append('sections_url', window.location.pathname); }
        options = { method: 'POST', headers: { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' }, body: payload };
      } else {
        const body = { items: payload };
        if (ids.length) { body.sections = ids.join(','); body.sections_url = window.location.pathname; }
        options = { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(body) };
      }
      const res = await fetch(`${PS.routes.cartAdd}.js`, options);
      const data = await res.json();
      if (!res.ok || data.status) throw new Error(data.description || data.message || PS.strings.error);
      this.render(data.sections);
      await this.refreshCount();
      document.dispatchEvent(new CustomEvent('ps:cart-updated'));
      if (this.drawer()) Drawer.open(this.drawer(), trigger);
      else toast(PS.strings.added);
    },
    async change(line, quantity) {
      document.body.classList.add('cart-is-updating');
      try {
        const ids = this.sectionIds();
        const body = { line, quantity };
        if (ids.length) { body.sections = ids.join(','); body.sections_url = window.location.pathname; }
        const res = await fetch(`${PS.routes.cartChange}.js`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
          body: JSON.stringify(body)
        });
        const data = await res.json();
        if (!res.ok || data.status) throw new Error(data.description || data.message || PS.strings.error);
        this.render(data.sections);
        this.setCount(data.item_count);
        document.dispatchEvent(new CustomEvent('ps:cart-updated'));
      } catch (err) {
        toast(err.message || PS.strings.error);
      } finally {
        document.body.classList.remove('cart-is-updating');
      }
    },
    render(sections) {
      if (!sections) return;
      const html = sections['r-cart-drawer'];
      if (!html) return;
      const doc = new DOMParser().parseFromString(html, 'text/html');
      const fresh = doc.querySelector('[data-cart-drawer] .drawer__panel');
      const current = $('[data-cart-drawer] .drawer__panel');
      if (fresh && current) current.innerHTML = fresh.innerHTML;
    },
    async refreshCount() {
      try {
        const res = await fetch(`${PS.routes.cart}.js`, { headers: { Accept: 'application/json' } });
        const cart = await res.json();
        this.setCount(cart.item_count);
      } catch (e) { /* count stays as rendered */ }
    },
    setCount(n) {
      $$('[data-cart-count]').forEach((el) => {
        el.dataset.count = n;
        el.textContent = n > 0 ? n : '';
      });
    }
  };

  async function quickAdd(btn) {
    btn.classList.add('is-loading');
    btn.disabled = true;
    try {
      await Cart.add([{ id: Number(btn.dataset.quickAdd), quantity: 1 }], btn);
      btn.classList.add('is-added');
      setTimeout(() => btn.classList.remove('is-added'), 1600);
    } catch (err) {
      toast(err.message);
    } finally {
      btn.classList.remove('is-loading');
      btn.disabled = false;
    }
  }

  /* ---------- Global event delegation ---------- */
  document.addEventListener('click', (e) => {
    const searchOpen = e.target.closest('[data-search-open]');
    if (searchOpen && $('[data-search-overlay]')) { e.preventDefault(); Search.open(searchOpen); return; }
    if (e.target.closest('[data-search-close]')) { e.preventDefault(); Search.close(); return; }

    const cartOpen = e.target.closest('[data-cart-open]');
    if (cartOpen && Cart.drawer()) { e.preventDefault(); Drawer.open(Cart.drawer(), cartOpen); return; }

    const opener = e.target.closest('[data-drawer-open]');
    if (opener) {
      e.preventDefault();
      Drawer.open(document.getElementById(opener.dataset.drawerOpen), opener);
      return;
    }
    const closer = e.target.closest('[data-drawer-close]');
    if (closer) { e.preventDefault(); Drawer.close(closer.closest('[data-drawer]')); return; }

    const qtyBtn = e.target.closest('[data-qty-change]');
    if (qtyBtn) { e.preventDefault(); Cart.change(Number(qtyBtn.dataset.line), Number(qtyBtn.dataset.qtyChange)); return; }

    const qa = e.target.closest('[data-quick-add]');
    if (qa) { e.preventDefault(); e.stopPropagation(); quickAdd(qa); return; }
  });

  document.addEventListener('change', (e) => {
    const qtyInput = e.target.closest('[data-qty-input]');
    if (qtyInput) Cart.change(Number(qtyInput.dataset.line), Math.max(0, parseInt(qtyInput.value, 10) || 0));
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      if (Search.isOpen()) Search.close();
      else if (Drawer.active) Drawer.close();
    }
    if (e.key === 'Tab' && Drawer.active) trapFocus(e, $('.drawer__panel', Drawer.active));
  });

  /* ---------- Product page ---------- */
  function initProduct(root = document) {
    $$('[data-product-section]', root).forEach((section) => {
      const jsonEl = $('[data-product-json]', section);
      const form = $('form[data-product-form]', section);
      if (!jsonEl || !form) return;
      const data = JSON.parse(jsonEl.textContent);
      const fieldsets = $$('[data-option]', section);
      const idInput = $('[data-variant-id]', section);
      const addBtn = $('[data-add-button]', section);
      const addLabel = $('[data-add-label]', section);
      const errorEl = $('[data-form-error]', section);
      const sticky = $('[data-sticky-buy]', section);
      const stickyBtn = $('[data-sticky-add]', section);

      const selected = () => fieldsets.map((fs) => {
        const checked = $('input:checked', fs);
        return checked ? checked.value : null;
      });
      const currentVariant = () => {
        if (!fieldsets.length) return data.variants[0] || null;
        const sel = selected();
        if (sel.includes(null)) return null;
        return data.variants.find((v) => v.options.every((o, i) => o === sel[i])) || null;
      };

      const updateOptions = () => {
        const sel = selected();
        fieldsets.forEach((fs, idx) => {
          $$('[data-option-value]', fs).forEach((input) => {
            const ok = data.variants.some((v) => v.available && v.options[idx] === input.value &&
              v.options.every((o, i) => i === idx || sel[i] === null || sel[i] === o));
            input.closest('.swatch').classList.toggle('is-unavailable', !ok);
          });
          const checked = $('input:checked', fs);
          const label = $('[data-option-selected]', fs);
          if (label) label.textContent = checked ? checked.value : '';
        });
      };

      const setButtons = (v) => {
        let text = PS.strings.addToBag;
        let disabled = false;
        if (!v) {
          const missing = selected().includes(null);
          text = missing ? PS.strings.selectSize : PS.strings.unavailable;
          disabled = !missing;
        } else if (!v.available) {
          text = PS.strings.soldOut;
          disabled = true;
        }
        if (addLabel) addLabel.textContent = text;
        if (addBtn) addBtn.disabled = disabled;
        if (stickyBtn) { stickyBtn.textContent = text; stickyBtn.disabled = disabled; }
      };

      const updatePrice = (v) => {
        if (!v) return;
        $$('[data-price]', section).forEach((p) => {
          const now = $('[data-price-now]', p);
          const was = $('[data-price-was]', p);
          if (!now || !was) return;
          if (v.compare_at_price > v.price) {
            now.textContent = formatMoney(v.price);
            was.textContent = formatMoney(v.compare_at_price);
            was.hidden = false;
          } else {
            now.textContent = formatMoney(v.price);
            was.hidden = true;
          }
        });
      };

      const clearMissing = () => {
        fieldsets.forEach((fs) => {
          fs.classList.remove('is-missing');
          const hint = $('[data-option-hint]', fs);
          if (hint) hint.hidden = true;
        });
      };

      const showMissing = () => {
        const fs = fieldsets.find((f) => !$('input:checked', f));
        if (!fs) return;
        fs.classList.add('is-missing');
        const hint = $('[data-option-hint]', fs);
        if (hint) hint.hidden = false;
        fs.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'center' });
        const first = $('input', fs);
        if (first) first.focus({ preventScroll: true });
      };

      const onChange = () => {
        const v = currentVariant();
        updateOptions();
        setButtons(v);
        updatePrice(v);
        if (!selected().includes(null)) clearMissing();
        if (v && idInput) {
          idInput.value = v.id;
          idInput.disabled = false;
          const buy = $('.buy[data-needs-choice]', section);
          if (buy) buy.removeAttribute('data-needs-choice');
          const url = new URL(window.location.href);
          url.searchParams.set('variant', v.id);
          window.history.replaceState({}, '', url.toString());
        }
      };

      section.addEventListener('change', (e) => {
        if (e.target.matches('[data-option-value]')) onChange();
      });

      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const v = currentVariant();
        if (!v) { showMissing(); return; }
        if (!v.available) return;
        if (errorEl) errorEl.hidden = true;
        addBtn.classList.add('is-loading');
        try {
          const fd = new FormData(form);
          fd.set('id', v.id);
          if (!fd.get('quantity')) fd.set('quantity', '1');
          await Cart.add(fd, addBtn);
        } catch (err) {
          if (errorEl) { errorEl.textContent = err.message; errorEl.hidden = false; }
        } finally {
          addBtn.classList.remove('is-loading');
        }
      });

      if (stickyBtn) {
        stickyBtn.addEventListener('click', () => {
          const v = currentVariant();
          if (!v) { showMissing(); return; }
          if (typeof form.requestSubmit === 'function') form.requestSubmit();
          else form.dispatchEvent(new Event('submit', { cancelable: true, bubbles: true }));
        });
      }

      if (sticky && addBtn && 'IntersectionObserver' in window) {
        new IntersectionObserver(([entry]) => {
          const show = !entry.isIntersecting && entry.boundingClientRect.top < 0;
          sticky.classList.toggle('is-visible', show);
          sticky.setAttribute('aria-hidden', String(!show));
          if (stickyBtn) stickyBtn.tabIndex = show ? 0 : -1;
        }).observe(addBtn);
      }

      updateOptions();
    });
  }

  /* ---------- Product recommendations ---------- */
  function initRecommendations(root = document) {
    $$('[data-recommendations]', root).forEach(async (el) => {
      if (el.children.length || !el.dataset.url) return;
      try {
        const res = await fetch(el.dataset.url);
        const doc = new DOMParser().parseFromString(await res.text(), 'text/html');
        const fresh = doc.querySelector('[data-recommendations]');
        if (fresh && fresh.innerHTML.trim()) el.innerHTML = fresh.innerHTML;
      } catch (e) { /* section stays empty */ }
    });
  }

  /* ---------- Boot ---------- */
  function init(root = document) {
    initProduct(root);
    initRecommendations(root);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => init());
  else init();
  document.addEventListener('shopify:section:load', (e) => init(e.target));

  window.PS.formatMoney = formatMoney;
  window.PS.cart = Cart;
})();
