/* Live search: suggestions, products and collections as you type, typo and nickname rescue, recent searches.
   Uses Shopify's predictive search endpoint. Products are matched on their title only and then checked again here,
   so a search for a club, a country or a player shows jerseys for that club, country or player and nothing else. */
(function () {
  'use strict';
  var panel = document.querySelector('.ald-srch');
  if (!panel || window.ALDSearch) return;

  var form = panel.querySelector('form'), input = form.querySelector('input[type=search]');
  var idle = panel.querySelector('[data-idle]'), res = panel.querySelector('[data-res]'), live = panel.querySelector('[data-live]');
  var fmt = panel.getAttribute('data-fmt') || '{{amount}}', KEY = 'ald-searches';

  /* nicknames and short forms mapped to the words that actually appear in product titles (no accents; matching ignores them).
     Words that belong to more than one club (madrid, united, city) are left alone so they show every club. */
  var ALIAS = {
    'barca': 'barcelona', 'fcb': 'barcelona', 'blaugrana': 'barcelona',
    'man utd': 'man united', 'man u': 'man united', 'mufc': 'man united', 'manchester united': 'man united',
    'manchester city': 'man city', 'mcfc': 'man city',
    'tottenham': 'spurs', 'thfc': 'spurs', 'juve': 'juventus', 'atleti': 'atletico',
    'paris': 'psg', 'paris saint germain': 'psg', 'paris saint-germain': 'psg',
    'real': 'real madrid', 'rm': 'real madrid', 'bayern': 'bayern munich',
    'cr7': 'ronaldo', 'cristiano': 'ronaldo', 'leo': 'messi', 'lionel': 'messi', 'yamal': 'lamine', 'kylian': 'mbappe',
    'spiderman': 'spidey', 'spider man': 'spidey', 'worldcup': 'wc 2026', 'world cup': 'wc 2026', 'wc': 'wc 2026',
    'arg': 'argentina', 'bra': 'brazil', 'eng': 'england', 'ita': 'italy', 'por': 'portugal'
  };
  var NOISE = /\b(jerseys?|shirts?|kits?|tees?|t-shirts?|football|soccer)\b/gi;

  function plain(s) {
    s = String(s || '').toLowerCase();
    return s.normalize ? s.normalize('NFD').replace(/[̀-ͯ]/g, '') : s;
  }
  function norm(q) { return plain(q).trim().replace(/\s+/g, ' '); }
  function alias(q) {
    var n = norm(q);
    if (ALIAS[n]) return ALIAS[n];
    var o = n.split(' ').map(function (w) { return ALIAS[w] || w; }).join(' ');
    return o !== n ? o : null;
  }
  function denoise(q) { var d = q.replace(NOISE, ' ').replace(/\s+/g, ' ').trim(); return d && norm(d) !== norm(q) ? d : null; }
  function longest(q) { var w = norm(q).split(' ').sort(function (a, b) { return b.length - a.length; })[0]; return w && w !== norm(q) && w.length > 2 ? w : null; }
  function trimmed(q) { var n = norm(q); return n.length >= 4 ? n.slice(0, -1) : null; }

  /* every word of the query has to start a word in the title */
  function matches(p, q) {
    var t = ' ' + plain(p.title).replace(/[^a-z0-9]+/g, ' ');
    return plain(q).split(/[^a-z0-9]+/).filter(Boolean).every(function (w) { return t.indexOf(' ' + w) > -1; });
  }

  function el(t, c, x) { var e = document.createElement(t); if (c) e.className = c; if (x != null) e.textContent = x; return e; }
  function n2(x, d) { return x.toFixed(d).replace(/\B(?=(\d{3})+(?!\d))/g, ','); }
  function money(v) {
    return fmt.replace(/\{\{\s*(\w+)\s*\}\}/, function (m, k) { return k === 'amount_no_decimals' ? n2(Math.round(v), 0) : n2(v, 2); }).replace(/\.00(?!\d)/, '');
  }
  function searchUrl(q, from) {
    return '/search?q=' + encodeURIComponent(q) + '&type=product&options%5Bprefix%5D=last&options%5Bfields%5D=title' + (from ? '&from=' + encodeURIComponent(from) : '');
  }

  function suggest(q, signal) {
    var u = '/search/suggest.json?q=' + encodeURIComponent(q) + '&resources%5Btype%5D=product,collection,query&resources%5Blimit%5D=10&resources%5Blimit_scope%5D=each&resources%5Boptions%5D%5Bunavailable_products%5D=last&resources%5Boptions%5D%5Bfields%5D=title';
    return fetch(u, { signal: signal }).then(function (r) { return r.ok ? r.json() : null; }).then(function (j) {
      var r = j && j.resources && j.resources.results;
      if (!r) return null;
      r.products = (r.products || []).filter(function (p) { return matches(p, q); });
      return r;
    });
  }

  /* try the query as typed, then smarter variants, until something comes back */
  function smart(q, signal) {
    var tries = [q, alias(q), denoise(q), longest(q), trimmed(q)].filter(function (c, i, a) { return c && a.indexOf(c) === i; }).slice(0, 4);
    var i = 0;
    function next(last) {
      if (i >= tries.length) return Promise.resolve(last ? { r: last, used: q, changed: false } : null);
      var c = tries[i++];
      return suggest(c, signal).then(function (r) {
        if (r && r.products && r.products.length) return { r: r, used: c, changed: norm(c) !== norm(q) };
        return next(i === 1 ? r : last);
      });
    }
    return next(null);
  }
  window.ALDSearch = { smart: function (q) { return smart(q); }, url: searchUrl };

  /* recent searches */
  function recent() { try { var l = JSON.parse(localStorage.getItem(KEY) || '[]'); return Array.isArray(l) ? l.filter(function (x) { return typeof x === 'string'; }) : []; } catch (e) { return []; } }
  function save(q) {
    q = (q || '').trim();
    if (q.length < 2) return;
    var l = [q].concat(recent().filter(function (x) { return norm(x) !== norm(q); })).slice(0, 6);
    try { localStorage.setItem(KEY, JSON.stringify(l)); } catch (e) {}
    drawRecent();
  }
  function drawRecent() {
    var box = idle.querySelector('[data-recent]'), l = recent();
    if (!box) return;
    box.textContent = '';
    if (!l.length) { box.hidden = true; return; }
    box.hidden = false;
    var h = el('h4', null, box.getAttribute('data-heading') || 'Recent searches'), ul = el('ul');
    l.forEach(function (q) {
      var li = el('li'), a = el('a', null, q);
      a.href = searchUrl(q);
      a.setAttribute('data-nav', '');
      li.appendChild(a);
      ul.appendChild(li);
    });
    var clear = el('button', 'ald-srch__clear', 'Clear');
    clear.type = 'button';
    clear.addEventListener('click', function () { try { localStorage.removeItem(KEY); } catch (e) {} drawRecent(); input.focus(); });
    box.appendChild(h); box.appendChild(ul); box.appendChild(clear);
  }

  /* rendering */
  var tierLinks = [].slice.call(idle.querySelectorAll('[data-tiers] a')).map(function (a) { return { t: a.textContent, h: a.getAttribute('href') }; });
  function list(title, items) {
    var box = el('div'), ul = el('ul');
    box.appendChild(el('h4', null, title));
    items.forEach(function (it) {
      var li = el('li'), a = el('a', null, it.t);
      a.href = it.h;
      a.setAttribute('data-nav', '');
      li.appendChild(a);
      ul.appendChild(li);
    });
    box.appendChild(ul);
    return box;
  }
  function render(q, out) {
    res.textContent = '';
    idle.hidden = true;
    res.hidden = false;
    var r = out ? out.r : null, prods = ((r && r.products) || []).slice(0, 6), cols = (r && r.collections) || [], qs = (r && r.queries) || [];
    var wrap = el('div', 'ald-sg'), left = el('div', 'ald-sg__l'), right = el('div', 'ald-sg__r');
    if (out && out.changed && prods.length) {
      var note = el('p', 'ald-sg__note');
      note.appendChild(document.createTextNode('No exact match for “' + q + '”. Showing “'));
      note.appendChild(el('b', null, out.used));
      note.appendChild(document.createTextNode('”.'));
      right.appendChild(note);
    }
    var sugg = qs.slice(0, 5).map(function (x) { return { t: x.text, h: searchUrl(x.text) }; });
    if (sugg.length) left.appendChild(list('Suggestions', sugg));
    var cl = cols.slice(0, 4).map(function (c) { return { t: c.title, h: c.url }; });
    if (cl.length) left.appendChild(list('Collections', cl));
    if (prods.length) {
      var grid = el('div', 'ald-sg__p');
      prods.forEach(function (p) {
        var a = el('a', 'ald-sg__c');
        a.href = p.url;
        a.setAttribute('data-nav', '');
        a.setAttribute('data-prod', '');
        var m = el('div', 'ald-sg__m');
        var src = (p.featured_image && p.featured_image.url) || p.image;
        if (src) { var im = document.createElement('img'); im.src = src + (src.indexOf('?') > -1 ? '&' : '?') + 'width=400'; im.alt = ''; im.loading = 'lazy'; m.appendChild(im); }
        a.appendChild(m);
        var t = el('div', 'ald-sg__t');
        t.appendChild(el('span', null, p.title));
        t.appendChild(el('span', null, p.available === false ? 'Sold out' : money(parseFloat(p.price))));
        a.appendChild(t);
        grid.appendChild(a);
      });
      right.appendChild(grid);
      var all = el('a', 'ald-sg__all', 'See all results for “' + (out.changed ? out.used : q) + '” →');
      all.href = searchUrl(out.changed ? out.used : q, out.changed ? q : null);
      all.setAttribute('data-nav', '');
      right.appendChild(all);
    } else {
      right.appendChild(el('p', 'ald-sg__none', 'Nothing matched “' + q + '”. Check the spelling, try a club, a country or a player, or pick a tier.'));
      if (tierLinks.length) left.appendChild(list('Shop by tier', tierLinks));
    }
    wrap.appendChild(left); wrap.appendChild(right);
    res.appendChild(wrap);
    live.textContent = prods.length ? prods.length + ' products found' : 'No products found';
  }
  function showIdle() { res.hidden = true; idle.hidden = false; res.textContent = ''; live.textContent = ''; }

  /* typing */
  var timer = null, ctl = null, seq = 0;
  input.addEventListener('input', function () {
    clearTimeout(timer);
    var q = input.value.trim();
    if (ctl) ctl.abort();
    if (q.length < 2) { showIdle(); return; }
    timer = setTimeout(function () {
      var my = ++seq;
      ctl = window.AbortController ? new AbortController() : null;
      smart(q, ctl && ctl.signal).then(function (out) { if (my === seq && input.value.trim() === q) render(q, out); }).catch(function () {});
    }, 160);
  });

  /* every search form on the site matches on titles only, and remembers what was searched */
  document.addEventListener('submit', function (e) {
    var f = e.target;
    if (!f || !f.getAttribute || f.getAttribute('role') !== 'search') return;
    var qi = f.querySelector('input[name=q]');
    if (qi && qi.value.trim()) save(qi.value);
    if (!f.querySelector('[name="options[fields]"]')) {
      var h = document.createElement('input');
      h.type = 'hidden'; h.name = 'options[fields]'; h.value = 'title';
      f.appendChild(h);
    }
  }, true);
  form.addEventListener('submit', function (e) { if (!input.value.trim()) { e.preventDefault(); input.focus(); } });
  panel.addEventListener('click', function (e) {
    var a = e.target.closest('a[data-nav]');
    if (!a) return;
    if (a.hasAttribute('data-prod')) { save(input.value); return; }
    if (/\/search\?/.test(a.getAttribute('href') || '')) save(decodeURIComponent((a.getAttribute('href').match(/[?&]q=([^&]*)/) || [, ''])[1].replace(/\+/g, ' ')));
  });

  /* arrow keys walk the results, Escape (handled globally) closes */
  panel.addEventListener('keydown', function (e) {
    if (e.key !== 'ArrowDown' && e.key !== 'ArrowUp') return;
    var nav = [].slice.call(panel.querySelectorAll('a[data-nav]')).filter(function (a) { return a.offsetParent; });
    if (!nav.length) return;
    var i = nav.indexOf(document.activeElement);
    e.preventDefault();
    if (e.key === 'ArrowDown') nav[Math.min(i + 1, nav.length - 1)].focus();
    else if (i <= 0) input.focus();
    else nav[i - 1].focus();
  });

  /* a fresh open always starts clean */
  new MutationObserver(function () {
    if (document.body.getAttribute('data-ald') === 'search') { drawRecent(); if (input.value.trim().length < 2) showIdle(); }
  }).observe(document.body, { attributes: true, attributeFilter: ['data-ald'] });

  /* landing on a results page counts as a search too (what the person typed, not the rescued query) */
  if (/^\/search\/?$/.test(location.pathname)) {
    var p = new URLSearchParams(location.search), s = p.get('from') || p.get('q');
    if (s) save(s);
  }
  drawRecent();
})();
