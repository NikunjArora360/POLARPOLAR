/* Interaction feedback. Loaded after ald.js; additive and delegated, so re-rendered cart and product markup keeps working.
   No scroll-triggered reveals: content is visible as soon as it renders. */
(function () {
  'use strict';
  if (window.__aldMotion) return;
  window.__aldMotion = true;

  var doc = document, B = doc.body;
  var $ = function (s, r) { return (r || doc).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || doc).querySelectorAll(s)); };

  /* ---------- product gallery (phones): counter follows the swipe, tap to advance ---------- */
  var gal = $('.ald-pdp__scroll'), ct = $('[data-ald-ct]');
  if (gal && ct) {
    var slides = Array.prototype.slice.call(gal.children), total = slides.length, cur = 0, ticking = false;
    var pad = function (n) { return (n < 10 ? '0' : '') + n; };
    gal.addEventListener('scroll', function () {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(function () {
        ticking = false;
        var step = slides[1] ? slides[1].offsetLeft - slides[0].offsetLeft : gal.clientWidth;
        var i = Math.max(0, Math.min(total - 1, Math.round(gal.scrollLeft / (step || 1))));
        if (i !== cur) { cur = i; ct.textContent = pad(i + 1) + ' / ' + pad(total); }
      });
    }, { passive: true });
    ct.addEventListener('click', function () {
      var s = slides[(cur + 1) % total];
      gal.scrollTo({ left: s.offsetLeft - gal.offsetLeft, behavior: 'smooth' });
    });
  }

  /* ---------- cart: count pop, one screen-reader message, immediate quantity feedback ---------- */
  var counts = $$('[data-ald-count]'), seen = parseInt((counts[0] || {}).textContent, 10) || 0;
  var live = doc.createElement('div');
  live.className = 'ald-sr';
  live.setAttribute('role', 'status');
  live.setAttribute('aria-live', 'polite');
  B.appendChild(live);
  function say(t) { live.textContent = ''; setTimeout(function () { live.textContent = t; }, 40); }
  if (counts[0] && 'MutationObserver' in window) {
    new MutationObserver(function () {
      var n = parseInt(counts[0].textContent, 10) || 0;
      if (n === seen) return;
      if (n > seen) {
        var c = $('.ald-hdr .ald-cnt');
        if (c) { c.classList.remove('is-bump'); void c.offsetWidth; c.classList.add('is-bump'); setTimeout(function () { c.classList.remove('is-bump'); }, 500); }
        say('Added to bag. ' + n + (n === 1 ? ' item' : ' items') + ' in bag.');
      } else {
        say(n ? 'Bag updated. ' + n + (n === 1 ? ' item' : ' items') + ' in bag.' : 'Bag is empty');
      }
      seen = n;
    }).observe(counts[0], { childList: true, characterData: true, subtree: true });
  }

  /* runs after ald.js has read the target quantity, so it only mirrors the result on screen */
  doc.addEventListener('click', function (e) {
    var q = e.target.closest('[data-ald-q]');
    if (!q) return;
    var line = q.closest('.ald-line');
    if (!line) return;
    var target = +q.getAttribute('data-ald-q');
    if (target <= 0) { line.classList.add('is-removing'); return; }
    var num = $('.ald-qty span', line), minus = $('[data-dir=dn]', line), plus = $('[data-dir=up]', line);
    if (num) num.textContent = target;
    if (minus) minus.setAttribute('data-ald-q', target - 1);
    if (plus) plus.setAttribute('data-ald-q', target + 1);
    line.classList.add('is-removing');
  });

  /* ---------- touch: drag a drawer sideways to dismiss it ---------- */
  var drag = null;
  doc.addEventListener('touchstart', function (e) {
    drag = null;
    var el = e.target.closest && e.target.closest('.ald-menu, .ald-cart');
    if (!el || e.touches.length !== 1) return;
    var cart = el.classList.contains('ald-cart');
    if (B.getAttribute('data-ald') !== (cart ? 'cart' : 'menu')) return;
    var t = e.touches[0];
    drag = { el: el, dir: cart ? 1 : -1, x0: t.clientX, y0: t.clientY, dx: 0, t0: Date.now(), w: el.offsetWidth, on: false, decided: false };
  }, { passive: true });
  doc.addEventListener('touchmove', function (e) {
    if (!drag) return;
    var t = e.touches[0], mx = t.clientX - drag.x0, my = t.clientY - drag.y0;
    if (!drag.decided) {
      if (Math.abs(mx) < 8 && Math.abs(my) < 8) return;
      drag.decided = true;
      drag.on = Math.abs(mx) > Math.abs(my) * 1.4 && mx * drag.dir > 0;
      if (drag.on) drag.el.style.transition = 'none';
    }
    if (!drag.on) return;
    drag.dx = mx * drag.dir > 0 ? mx : 0;
    drag.el.style.transform = 'translate3d(' + drag.dx + 'px,0,0)';
  }, { passive: true });
  function endDrag() {
    var d = drag;
    drag = null;
    if (!d || !d.on) return;
    var quick = Math.abs(d.dx) > 30 && Math.abs(d.dx) / Math.max(1, Date.now() - d.t0) > 0.5, far = Math.abs(d.dx) > d.w * 0.3;
    d.el.style.transition = '';
    d.el.style.transform = '';
    if (quick || far) B.setAttribute('data-ald', '');
  }
  doc.addEventListener('touchend', endDrag, { passive: true });
  doc.addEventListener('touchcancel', endDrag, { passive: true });

  /* ---------- theme editor: sections that own listeners are reloaded when the merchant edits them ---------- */
  if (window.Shopify && window.Shopify.designMode) {
    doc.addEventListener('shopify:section:load', function (e) {
      if (e.target && e.target.querySelector && e.target.querySelector('[data-ald-buy],[data-ald-grid],[data-ald-filters],.ald-hdr')) location.reload();
    });
  }
})();