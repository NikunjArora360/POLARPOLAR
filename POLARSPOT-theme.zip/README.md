# POLARSPOT

Shopify theme code for the POLARSPOT store (`vd9xuj-ds.myshopify.com`, storefront polarspot.online).

## Snapshot

| | |
|---|---|
| Theme | **POLARSPOT v4 (mobile fixes, no radio)** |
| Theme ID | `gid://shopify/OnlineStoreTheme/169963422053` |
| Role when saved | MAIN (live) |
| Last updated on Shopify | 2026-10-29 13:48 UTC |
| Saved | 2026-10-29, straight from the Shopify Admin API |
| Files | 593 (every file in the theme) |

Every text file was written byte-for-byte from the API response. Liquid, JS, CSS and Markdown files match Shopify's own MD5 checksums. JSON files (templates, settings, section groups, locales) match in size apart from the auto-generated `/* IMPORTANT ... */` banner Shopify adds when reading them; their checksums differ only because of that banner and formatting.

## How the theme is layered

The store started from Shopify's **Horizon** theme and has two custom layers on top. Horizon files are untouched.

**ALD layer (what the live store runs)**
- `layout/ald.liquid`: the page shell, with the header, cart drawer and overlay
- `sections/ald-*.liquid`: header, vault gate, tiers, product, collection, cart drawer and the other pages
- `snippets/ald-*.liquid`: product card, accordion and icons
- `assets/ald*.css`, `assets/ald*.js`: styles, menu and drawers, search, motion, accessibility, home-page behaviour, the saved-items list (`ald-extra.js`)
- `assets/ps-*.css`: styles referenced by the live homepage
- `assets/ald-favicon.svg`: the "P" favicon
- `templates/*.json`, `config/settings_data.json`, `sections/header-group.json`, `sections/footer-group.json`: which sections each page uses, and the saved settings

**REP layer (older, not used by the live layout)**
- `layout/rep.liquid`, `sections/r-*`, `snippets/r-*`, `assets/r-*`, `assets/rep*`

**Leftovers from removed features**
- `sections/ald-radio.liquid`, `assets/ald-radio.css`, `assets/ald-radio.js` are empty stubs. The radio was removed from the layout, and the Shopify connector can't delete files. They can be deleted in the code editor or with the CLI.

## Using this repo

Push this code to a theme (unpublished first):

```bash
shopify theme push --store vd9xuj-ds.myshopify.com --unpublished --theme "POLARSPOT"
```

Pull the latest from Shopify back into this folder:

```bash
shopify theme pull --store vd9xuj-ds.myshopify.com --theme 169963422053
```

Notes
- Theme settings changed in the theme editor are saved in `config/settings_data.json` and the `templates/*.json` files, so pull before you commit if you edit in the editor.
- `.gitattributes` turns off line-ending conversion so files stay byte-identical to what Shopify stores.
- An older unpublished theme named "POLARSPOT" (`169935962469`) also exists on Shopify. It still has the radio and is not in this repo.
